import { createContext, useContext, useReducer, useCallback } from "react";

const AppContext = createContext(null);

const initialState = {
  screen: "home",
  user: null,
  selectedRest: null,
  cart: [],
  orderTableNum: null,
  activeMenuCat: null,
  showPayment: false,
  paid: false,
  payMethod: null,
  orders: [],
  reservations: {},
  resForm: {
    date: "",
    persons: 2,
    time: "",
    floorIdx: 0,
    tableId: null,
    done: false,
  },
  toast: null,
  adminFloors: [
    { id: 1, name: "Parter", tables: [], elements: [], type: "indoor" },
  ],
  adminFloorIdx: 0,
  selectedNode: null,
  // Notificări client
  notifications: [],
  unreadCount: 0,
  // Restaurante proprietar
  myRestaurants: [],
};

function reducer(state, { type, payload }) {
  switch (type) {
    case "NAVIGATE":
      return { ...state, screen: payload };
    case "SET_REST":
      return { ...state, selectedRest: payload, screen: "restaurant" };
    case "SET_USER":
      return { ...state, user: payload };
    case "SET_TOAST":
      return { ...state, toast: payload };
    case "SET_MENU_CAT":
      return { ...state, activeMenuCat: payload };
    case "SET_PAYMENT":
      return { ...state, showPayment: payload };
    case "SET_PAID":
      return { ...state, paid: payload.paid, payMethod: payload.method };
    case "SET_ORDER_TABLE":
      return { ...state, orderTableNum: payload };

    // ── Coș ──
    case "CART_ADD": {
      const ex = state.cart.find((i) => i.id === payload.id);
      return {
        ...state,
        cart: ex
          ? state.cart.map((i) =>
              i.id === payload.id ? { ...i, qty: i.qty + 1 } : i,
            )
          : [...state.cart, { ...payload, qty: 1 }],
      };
    }
    case "CART_REMOVE": {
      const ex = state.cart.find((i) => i.id === payload);
      return {
        ...state,
        cart:
          ex?.qty === 1
            ? state.cart.filter((i) => i.id !== payload)
            : state.cart.map((i) =>
                i.id === payload ? { ...i, qty: i.qty - 1 } : i,
              ),
      };
    }
    case "CART_CLEAR":
      return { ...state, cart: [] };

    // ── Comenzi ──
    case "PLACE_ORDER":
      return { ...state, cart: [], orders: [...state.orders, payload] };
    case "ORDER_UPDATE":
      return {
        ...state,
        orders: state.orders.map((o) =>
          o.id === payload.id
            ? {
                ...o,
                status: payload.status,
                waiterId: payload.waiterId,
                waiterName: payload.waiterName,
              }
            : o,
        ),
      };
    case "ORDER_REMOVE":
      return { ...state, orders: state.orders.filter((o) => o.id !== payload) };

    // ── Notificări ──
    case "ADD_NOTIFICATION":
      return {
        ...state,
        notifications: [payload, ...state.notifications],
        unreadCount: state.unreadCount + 1,
      };
    case "MARK_NOTIFICATIONS_READ":
      return {
        ...state,
        notifications: state.notifications.map((n) => ({ ...n, isRead: true })),
        unreadCount: 0,
      };

    // ── Rezervări ──
    case "RES_FORM":
      return { ...state, resForm: { ...state.resForm, ...payload } };
    case "RES_CONFIRM": {
      const { restId, slot, tableId } = payload;
      return {
        ...state,
        reservations: {
          ...state.reservations,
          [restId]: {
            ...(state.reservations[restId] || {}),
            [slot]: [...(state.reservations[restId]?.[slot] || []), tableId],
          },
        },
        resForm: { ...state.resForm, done: true },
      };
    }
    case "RES_RESET":
      return {
        ...state,
        resForm: {
          date: "",
          persons: 2,
          time: "",
          floorIdx: 0,
          tableId: null,
          done: false,
        },
      };

    // ── Restaurante proprietar ──
    case "SET_MY_RESTAURANTS":
      return { ...state, myRestaurants: payload };
    case "ADD_MY_RESTAURANT":
      return { ...state, myRestaurants: [...state.myRestaurants, payload] };

    // ── Admin planșeu ──
    case "ADMIN_SET_FLOORS":
      return { ...state, adminFloors: payload };
    case "ADMIN_SET_FLOOR_IDX":
      return { ...state, adminFloorIdx: payload, selectedNode: null };
    case "ADMIN_SET_NODE":
      return { ...state, selectedNode: payload };
    case "ADMIN_ADD_FLOOR": {
      const newId = Math.max(...state.adminFloors.map((f) => f.id), 0) + 1;
      const newNum = state.adminFloors.filter(
        (f) => f.type !== "terrace",
      ).length;
      return {
        ...state,
        adminFloors: [
          ...state.adminFloors,
          {
            id: newId,
            name: `Etaj ${newNum}`,
            tables: [],
            elements: [],
            type: "indoor",
          },
        ],
        adminFloorIdx: state.adminFloors.length,
      };
    }
    case "ADMIN_ADD_TABLE": {
      const floor = state.adminFloors[state.adminFloorIdx];
      const tableNum = (floor.tables?.length || 0) + 1;
      const prefix = floor.type === "terrace" ? "E" : "T";
      const newTable = {
        id: `t_${Date.now()}`,
        label: `${prefix}${tableNum}`,
        seats: payload.seats,
        x: 20 + (tableNum % 5) * 60,
        y: 20 + Math.floor(tableNum / 5) * 70,
      };
      return {
        ...state,
        adminFloors: state.adminFloors.map((f, i) =>
          i === state.adminFloorIdx
            ? { ...f, tables: [...(f.tables || []), newTable] }
            : f,
        ),
      };
    }
    case "ADMIN_ADD_ELEMENT": {
      return {
        ...state,
        adminFloors: state.adminFloors.map((f, i) =>
          i === state.adminFloorIdx
            ? { ...f, elements: [...(f.elements || []), payload] }
            : f,
        ),
      };
    }
    case "ADMIN_MOVE_NODE": {
      const { nodeId, x, y } = payload;
      return {
        ...state,
        adminFloors: state.adminFloors.map((f, i) => {
          if (i !== state.adminFloorIdx) return f;
          return {
            ...f,
            tables: (f.tables || []).map((t) =>
              t.id === nodeId ? { ...t, x, y } : t,
            ),
            elements: (f.elements || []).map((e) =>
              e.id === nodeId ? { ...e, x, y } : e,
            ),
          };
        }),
      };
    }
    case "ADMIN_DELETE_NODE": {
      return {
        ...state,
        selectedNode: null,
        adminFloors: state.adminFloors.map((f, i) => {
          if (i !== state.adminFloorIdx) return f;
          return {
            ...f,
            tables: (f.tables || []).filter((t) => t.id !== payload),
            elements: (f.elements || []).filter((e) => e.id !== payload),
          };
        }),
      };
    }

    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const navigate = useCallback(
    (screen) => dispatch({ type: "NAVIGATE", payload: screen }),
    [],
  );
  const showToast = useCallback((msg) => {
    dispatch({ type: "SET_TOAST", payload: msg });
    setTimeout(() => dispatch({ type: "SET_TOAST", payload: null }), 3000);
  }, []);
  const isLocked = useCallback(
    (feature) => {
      const plan = state.user?.plan || "free";
      const locked = { orders: ["free"], multifloor: ["free"] };
      return locked[feature]?.includes(plan);
    },
    [state.user],
  );

  const cartTotal = state.cart.reduce((s, i) => s + i.price * i.qty, 0);
  const cartCount = state.cart.reduce((s, i) => s + i.qty, 0);
  const cookingCount = state.orders.filter(
    (o) => o.status === "cooking",
  ).length;

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        navigate,
        showToast,
        isLocked,
        cartTotal,
        cartCount,
        cookingCount,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
